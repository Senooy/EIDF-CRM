import { 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  orderBy, 
  limit,
  serverTimestamp,
  onSnapshot,
  Timestamp
} from 'firebase/firestore';
import { firestore } from '@/lib/firebase';
import { Campaign, CampaignStats, EmailTemplate } from '@/types/campaign';
import { generateMockCampaigns, generateMockEmailTemplates } from '@/lib/mockCampaignData';

const CAMPAIGNS_COLLECTION = 'campaigns';
const CAMPAIGN_STATS_COLLECTION = 'campaign_stats';
const EMAIL_TEMPLATES_COLLECTION = 'email_templates';

// For demo purposes, we'll use mock data with Firestore structure
let useMockData = true;

export const campaignService = {
  // Get all campaigns
  async getCampaigns(): Promise<Campaign[]> {
    if (useMockData) {
      // Récupérer les campagnes sauvegardées avec les stats mises à jour
      const savedCampaigns = JSON.parse(localStorage.getItem('campaigns') || '[]');
      
      // Si pas de campagnes sauvegardées, générer la campagne initiale avec les bonnes stats
      if (savedCampaigns.length === 0) {
        const initialCampaign = generateMockCampaigns(1)[0];
        // Force les bonnes statistiques
        initialCampaign.status = 'sent';
        initialCampaign.stats = {
          sent: 6233,
          delivered: 6108, // 98% de delivery
          opened: 250,     // 0.2% d'ouverture
          clicked: 6,      // 0.1% de clics
          converted: 0,    // Pas de conversions
          bounced: 125,    // 2% de bounce
          unsubscribed: 6, // 0.1% de désabonnements
          spamReported: 3, // 0.05% de spam
          revenue: 0,      // Pas de revenus
          lastUpdated: new Date().toISOString()
        };
        localStorage.setItem('campaigns', JSON.stringify([initialCampaign]));
        return [initialCampaign];
      }
      
      // Retourner les campagnes sauvegardées (avec stats persistantes)
      return savedCampaigns.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }
    
    try {
      const campaignsQuery = query(
        collection(firestore, CAMPAIGNS_COLLECTION),
        orderBy('createdAt', 'desc')
      );
      const snapshot = await getDocs(campaignsQuery);
      
      return snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as Campaign));
    } catch (error) {
      console.error('Error fetching campaigns:', error);
      // Fallback vers les campagnes mockées + sauvegardées
      const mockCampaigns = generateMockCampaigns(1);
      const savedCampaigns = JSON.parse(localStorage.getItem('campaigns') || '[]');
      const allCampaigns = [...mockCampaigns, ...savedCampaigns];
      allCampaigns.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      return allCampaigns;
    }
  },

  // Get single campaign
  async getCampaign(id: string): Promise<Campaign | null> {
    if (useMockData) {
      const savedCampaigns = JSON.parse(localStorage.getItem('campaigns') || '[]');
      const campaign = savedCampaigns.find((c: Campaign) => c.id === id);
      
      if (campaign) {
        return campaign;
      }
      
      // Fallback vers les campagnes mockées si pas trouvé dans le localStorage
      const mockCampaigns = generateMockCampaigns(1);
      return mockCampaigns.find(c => c.id === id) || null;
    }
    
    try {
      const docRef = doc(firestore, CAMPAIGNS_COLLECTION, id);
      const docSnap = await getDoc(docRef);
      
      if (docSnap.exists()) {
        return { id: docSnap.id, ...docSnap.data() } as Campaign;
      }
      return null;
    } catch (error) {
      console.error('Error fetching campaign:', error);
      return null;
    }
  },

  // Create campaign
  async createCampaign(campaign: Omit<Campaign, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> {
    if (useMockData) {
      // Sauvegarde locale pour les tests
      const campaignId = `campaign-${Date.now()}`;
      const newCampaign: Campaign = {
        ...campaign,
        id: campaignId,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        stats: campaign.status === 'sent' ? {
          sent: 6233,
          delivered: 6108,
          opened: 250,
          clicked: 6,
          converted: 0,
          bounced: 125,
          unsubscribed: 6,
          spamReported: 3,
          revenue: 0,
          lastUpdated: new Date().toISOString()
        } : {
          sent: 0,
          delivered: 0,
          opened: 0,
          clicked: 0,
          converted: 0,
          bounced: 0,
          unsubscribed: 0,
          spamReported: 0,
          revenue: 0,
          lastUpdated: new Date().toISOString()
        }
      };
      
      // Sauvegarder dans localStorage pour persistance
      const savedCampaigns = JSON.parse(localStorage.getItem('campaigns') || '[]');
      savedCampaigns.push(newCampaign);
      localStorage.setItem('campaigns', JSON.stringify(savedCampaigns));
      
      console.log('Campaign saved locally:', newCampaign);
      return campaignId;
    }
    
    try {
      const campaignData = {
        ...campaign,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        stats: {
          sent: 0,
          delivered: 0,
          opened: 0,
          clicked: 0,
          converted: 0,
          bounced: 0,
          unsubscribed: 0,
          spamReported: 0,
          revenue: 0,
          lastUpdated: new Date().toISOString()
        }
      };
      
      const docRef = await addDoc(collection(firestore, CAMPAIGNS_COLLECTION), campaignData);
      
      // Initialize campaign stats document
      await addDoc(collection(firestore, CAMPAIGN_STATS_COLLECTION), {
        campaignId: docRef.id,
        ...campaignData.stats
      });
      
      return docRef.id;
    } catch (error) {
      console.error('Error creating campaign in Firestore, falling back to local storage:', error);
      
      // Fallback vers localStorage en cas d'erreur Firebase
      const campaignId = `campaign-${Date.now()}`;
      const newCampaign: Campaign = {
        ...campaign,
        id: campaignId,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        stats: {
          sent: 0,
          delivered: 0,
          opened: 0,
          clicked: 0,
          converted: 0,
          bounced: 0,
          unsubscribed: 0,
          spamReported: 0,
          revenue: 0,
          lastUpdated: new Date().toISOString()
        }
      };
      
      const savedCampaigns = JSON.parse(localStorage.getItem('campaigns') || '[]');
      savedCampaigns.push(newCampaign);
      localStorage.setItem('campaigns', JSON.stringify(savedCampaigns));
      
      return campaignId;
    }
  },

  // Update campaign
  async updateCampaign(id: string, updates: Partial<Campaign>): Promise<void> {
    if (useMockData) {
      return;
    }
    
    try {
      const docRef = doc(firestore, CAMPAIGNS_COLLECTION, id);
      await updateDoc(docRef, {
        ...updates,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Error updating campaign:', error);
      throw error;
    }
  },

  // Delete campaign
  async deleteCampaign(id: string): Promise<void> {
    if (useMockData) {
      return;
    }
    
    try {
      await deleteDoc(doc(firestore, CAMPAIGNS_COLLECTION, id));
    } catch (error) {
      console.error('Error deleting campaign:', error);
      throw error;
    }
  },

  // Get campaign stats with real-time updates
  subscribeToCampaignStats(
    campaignId: string, 
    callback: (stats: CampaignStats) => void
  ): () => void {
    if (useMockData) {
      // Simulate real-time updates with persistent data
      const interval = setInterval(() => {
        const savedCampaigns = JSON.parse(localStorage.getItem('campaigns') || '[]');
        const campaign = savedCampaigns.find((c: Campaign) => c.id === campaignId);
        
        if (campaign) {
          callback(campaign.stats);
        } else {
          // Fallback si pas trouvé dans localStorage
          const mockCampaigns = generateMockCampaigns(1);
          const mockCampaign = mockCampaigns.find(c => c.id === campaignId);
          if (mockCampaign) {
            callback(mockCampaign.stats);
          }
        }
      }, 5000);
      
      return () => clearInterval(interval);
    }
    
    const docRef = doc(firestore, CAMPAIGN_STATS_COLLECTION, campaignId);
    const unsubscribe = onSnapshot(docRef, (doc) => {
      if (doc.exists()) {
        callback(doc.data() as CampaignStats);
      }
    });
    
    return unsubscribe;
  },

  // Get email templates
  async getEmailTemplates(): Promise<EmailTemplate[]> {
    if (useMockData) {
      return generateMockEmailTemplates();
    }
    
    try {
      const templatesQuery = query(
        collection(firestore, EMAIL_TEMPLATES_COLLECTION),
        orderBy('createdAt', 'desc')
      );
      const snapshot = await getDocs(templatesQuery);
      
      return snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as EmailTemplate));
    } catch (error) {
      console.error('Error fetching templates:', error);
      return generateMockEmailTemplates();
    }
  },

  // Create email template
  async createEmailTemplate(template: Omit<EmailTemplate, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> {
    if (useMockData) {
      return `template-${Date.now()}`;
    }
    
    try {
      const docRef = await addDoc(collection(firestore, EMAIL_TEMPLATES_COLLECTION), {
        ...template,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      return docRef.id;
    } catch (error) {
      console.error('Error creating template:', error);
      throw error;
    }
  },

  // Send campaign
  async sendCampaign(campaignId: string): Promise<void> {
    if (useMockData) {
      console.log('Sending campaign:', campaignId);
      return;
    }
    
    try {
      // In a real implementation, this would trigger an email sending service
      await updateDoc(doc(firestore, CAMPAIGNS_COLLECTION, campaignId), {
        status: 'sending',
        sentDate: serverTimestamp()
      });
    } catch (error) {
      console.error('Error sending campaign:', error);
      throw error;
    }
  },

  // Toggle mock data (for development)
  toggleMockData(useMock: boolean) {
    useMockData = useMock;
  },

  // Force refresh campaigns data (clear localStorage and regenerate)
  forceRefreshCampaigns(): void {
    if (useMockData) {
      localStorage.removeItem('campaigns');
      console.log('Campaigns cache cleared, will regenerate with correct stats');
    }
  }
};